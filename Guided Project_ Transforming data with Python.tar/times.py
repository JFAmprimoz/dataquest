import read
import dateutil

def datetime_extract(date_time, param):
    date_time = dateutil.parser.parse(date_time)
    time = getattr(date_time, param)
          
    return time

    
df = read.load_data()

df['hour'] = df['submission_time'].apply(get_time, args=('hour',))

day_count = df['hour'].value_counts()

print(hour_count)

df['day'] = df['submission_time'].apply(get_time, args=('day',))

day_count = df['day'].value_counts()

print(day_count)