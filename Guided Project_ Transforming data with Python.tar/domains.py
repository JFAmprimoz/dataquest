import read
import tldextract as tldex

def process_urls(string):
    string = string.lower()
    split_domain = tldex.extract(string)
    string = split_domain.registered_domain
    return string
    
df = read.load_data()

domains = df['url'].apply(process_urls)


for name, row in domains[0:99].items():
    print("{0}: {1}".format(name, row))

