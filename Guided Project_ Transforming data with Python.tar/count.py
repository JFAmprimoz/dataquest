import read
import collections as co

df = read.load_data()
headlines = ""

for headline in df['headline']:
    headlines = headlines + str(headline).lower() + " "

words = headlines.split(' ')

print(co.Counter(words).most_common(100))